package com.example.gem_nest_mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
